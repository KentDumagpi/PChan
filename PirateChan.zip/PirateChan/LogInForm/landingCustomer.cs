﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogInForm
{
    public partial class landingCustomer : Form
    {
        SqlConnection sqlCon;
        public SqlCommand cmd;
        public SqlDataAdapter dataAdapter;
        public SqlDataReader dataReader;


        private PictureBox product;
        private Label productName;
        private Label ofStock;
        private Label productPrice;
        private string connection = "Data Source=.\\sqlexpress;Initial Catalog=pirateChanDB;Integrated Security=True;";

        private int userId;
        public landingCustomer(int userId)
        {
            InitializeComponent();
            sqlCon = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=pirateChanDB;Integrated Security=True;");
            this.userId = userId;

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void btnFigurine_Click(object sender, EventArgs e)
        {
            panelMainHome.Visible = false;
            panelMainHome.Enabled = false;
            panelMainFigurine.Visible = true;
            panelMainFigurine.Enabled = true;
            panelMainPlushy.Visible = false;
            panelMainPlushy.Enabled = false;
            fpanelMainFigurine.Controls.Clear(); // Clear existing picture boxes
            loadDataFigurine();

        }

        private void panelMenu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelHome_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void btnPlushy_Click(object sender, EventArgs e)
        {
            panelMainHome.Visible = false;
            panelMainHome.Enabled = false;
            panelMainFigurine.Visible = false;
            panelMainFigurine.Enabled = false;
            panelMainPlushy.Visible = true;
            panelMainPlushy.Enabled = true;
            panelMainPlushy.BringToFront();
            fpanelMainPlushy.Controls.Clear(); // Clear existing picture boxes
            loadDataPlushy();

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Logout();
        }

        private void Logout()
        {
            // Hide the current form (e.g., the main form)
            this.Hide();

            // Show the login form again
            loginPage login = new loginPage();
            login.ShowDialog();

            // After the login form is closed, show the current form again
            this.Show();
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void landingCustomer_Load(object sender, EventArgs e)
        {
            int id = userId;

            string query = "SELECT C_Firstname, C_Lastname, C_Age, C_Email, C_Address, C_Username FROM CUSTOMERS WHERE CID = @id";

            
            panelMainHome.Visible = true;
            panelMainHome.Enabled = true;
            panelMainFigurine.Visible = false;
            panelMainFigurine.Enabled = false;
            panelMainPlushy.Visible = false;
            panelMainPlushy.Enabled = false;
            fpanelMainHome.Controls.Clear(); // Clear existing picture boxes
            loadDataHome(userId);

        }
        private void loadDataHome(int userId)
        {
            // ...
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            panelMainHome.Visible = true;
            panelMainHome.Enabled = true;
            panelMainFigurine.Visible = false;
            panelMainFigurine.Enabled = false;
            panelMainPlushy.Visible = false;
            panelMainPlushy.Enabled = false;
            fpanelMainHome.Controls.Clear(); // Clear existing picture boxes
            loadDataHome();
        }

        private void loadDataHome()
        {
            try
            {
                sqlCon.Open();
                string query = "SELECT P_IMAGE, P_NAME, P_PRICE, P_QUANTITY, PID FROM PRODUCTS";
                cmd = new SqlCommand(query, sqlCon);
                dataReader = cmd.ExecuteReader();
                while (dataReader.Read())
                {
                    receipt.ColumnHeadersVisible = false;

                    long len = dataReader.GetBytes(0, 0, null, 0, 0);
                    byte[] array = new byte[System.Convert.ToInt32(len) + 1];
                    dataReader.GetBytes(0, 0, array, 0, System.Convert.ToInt32(len));
                    product = new PictureBox();
                    product.Width = 162;
                    product.Height = 170;
                    product.BackgroundImageLayout = ImageLayout.Zoom;
                    product.BorderStyle = BorderStyle.FixedSingle;
                    product.BackColor = Color.FromArgb(231, 235, 238);
                    product.Cursor = Cursors.Hand;
                    string productId = dataReader["PID"].ToString();
                    product.Tag = productId;

                    productPrice = new Label();
                    double price = Convert.ToDouble(dataReader["P_PRICE"]);
                    string formattedPrice = String.Format("{0:0.00}", price);
                    productPrice.Text = formattedPrice;
                    productPrice.BackColor = Color.FromArgb(35, 40, 45);
                    productPrice.ForeColor = Color.White;
                    productPrice.Width = 70;
                    productPrice.TextAlign = ContentAlignment.MiddleCenter;
                    productPrice.Font = new Font("Cooper Black", 11, FontStyle.Regular);

                    productName = new Label();
                    productName.Text = dataReader["P_NAME"].ToString();
                    productName.BackColor = Color.FromArgb(35, 40, 45);
                    productName.ForeColor = Color.White;
                    productName.Dock = DockStyle.Bottom;
                    productName.Height = 30;
                    productName.Font = new Font("Cooper Black", 12, FontStyle.Regular);
                    productName.TextAlign = ContentAlignment.MiddleCenter;
                    productName.Padding = new Padding(0, 5, 0, 0);

                    MemoryStream ms = new MemoryStream(array);
                    System.Drawing.Bitmap bitmap = new System.Drawing.Bitmap(ms);
                    product.BackgroundImage = bitmap;

                    product.Controls.Add(productPrice);
                    product.Controls.Add(productName);
                    fpanelMainHome.Controls.Add(product);

                    product.Click += new EventHandler(OnClick);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
            finally
            {
                if (dataReader != null)
                    dataReader.Close();
                if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                    sqlCon.Close();
            }
        }

        private void loadDataFigurine()
        {
            try
            {
                sqlCon.Open();
                string query = "SELECT P_IMAGE, P_NAME, P_PRICE, P_QUANTITY, P_CATEGORY, PID FROM PRODUCTS";
                cmd = new SqlCommand(query, sqlCon);
                dataReader = cmd.ExecuteReader();
                while (dataReader.Read())
                {
                    string category = dataReader["P_CATEGORY"].ToString().ToLower();
                    if ( category == "figurine")
                    {
                        receipt.ColumnHeadersVisible = false;

                        long len = dataReader.GetBytes(0, 0, null, 0, 0);
                        byte[] array = new byte[System.Convert.ToInt32(len) + 1];
                        dataReader.GetBytes(0, 0, array, 0, System.Convert.ToInt32(len));
                        product = new PictureBox();
                        product.Width = 162;
                        product.Height = 170;
                        product.BackgroundImageLayout = ImageLayout.Zoom;
                        product.BorderStyle = BorderStyle.FixedSingle;
                        product.BackColor = Color.FromArgb(231, 235, 238);
                        product.Cursor = Cursors.Hand;
                        string productId = dataReader["PID"].ToString();
                        product.Tag = productId;

                        productPrice = new Label();
                        double price = Convert.ToDouble(dataReader["P_PRICE"]);
                        string formattedPrice = String.Format("{0:0.00}", price);
                        productPrice.Text = formattedPrice;
                        productPrice.BackColor = Color.FromArgb(13, 16, 19);
                        productPrice.ForeColor = Color.White;
                        productPrice.Width = 70;
                        productPrice.TextAlign = ContentAlignment.MiddleCenter;
                        productPrice.Font = new Font("Cooper Black", 11, FontStyle.Regular);

                        productName = new Label();
                        productName.Text = dataReader["P_NAME"].ToString();
                        productName.BackColor = Color.FromArgb(13, 16, 19);
                        productName.ForeColor = Color.White;
                        productName.Dock = DockStyle.Bottom;
                        productName.Height = 30;
                        productName.Font = new Font("Cooper Black", 12, FontStyle.Regular);
                        productName.TextAlign = ContentAlignment.MiddleCenter;
                        productName.Padding = new Padding(0, 5, 0, 0);

                        MemoryStream ms = new MemoryStream(array);
                        System.Drawing.Bitmap bitmap = new System.Drawing.Bitmap(ms);
                        product.BackgroundImage = bitmap;

                        product.Controls.Add(productPrice);
                        product.Controls.Add(productName);
                        fpanelMainFigurine.Controls.Add(product);

                        product.Click += new EventHandler(OnClick);

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
            finally
            {
                if (dataReader != null)
                    dataReader.Close();
                if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                    sqlCon.Close();
            }
        }

        private void loadDataPlushy()
        {
            try
            {
                sqlCon.Open();
                string query = "SELECT P_IMAGE, P_NAME, P_PRICE, P_QUANTITY, P_CATEGORY, PID FROM PRODUCTS";
                cmd = new SqlCommand(query, sqlCon);
                dataReader = cmd.ExecuteReader();
                while (dataReader.Read())
                {
                    string category = dataReader["P_CATEGORY"].ToString().ToLower();
                    if (category == "plushy")
                    {
                        receipt.ColumnHeadersVisible = false;

                        long len = dataReader.GetBytes(0, 0, null, 0, 0);
                        byte[] array = new byte[System.Convert.ToInt32(len) + 1];
                        dataReader.GetBytes(0, 0, array, 0, System.Convert.ToInt32(len));
                        product = new PictureBox();
                        product.Width = 162;
                        product.Height = 170;
                        product.BackgroundImageLayout = ImageLayout.Zoom;
                        product.BorderStyle = BorderStyle.FixedSingle;
                        product.BackColor = Color.FromArgb(231, 235, 238);
                        product.Cursor = Cursors.Hand;
                        string productId = dataReader["PID"].ToString();
                        product.Tag = productId;

                        productPrice = new Label();
                        double price = Convert.ToDouble(dataReader["P_PRICE"]);
                        string formattedPrice = String.Format("{0:0.00}", price);
                        productPrice.Text = formattedPrice;
                        productPrice.BackColor = Color.FromArgb(35, 40, 45);
                        productPrice.ForeColor = Color.White;
                        productPrice.Width = 70;
                        productPrice.TextAlign = ContentAlignment.MiddleCenter;
                        productPrice.Font = new Font("Cooper Black", 11, FontStyle.Regular);

                        productName = new Label();
                        productName.Text = dataReader["P_NAME"].ToString();
                        productName.BackColor = Color.FromArgb(35, 40, 45);
                        productName.ForeColor = Color.White;
                        productName.Dock = DockStyle.Bottom;
                        productName.Height = 30;
                        productName.Font = new Font("Cooper Black", 12, FontStyle.Regular);
                        productName.TextAlign = ContentAlignment.MiddleCenter;
                        productName.Padding = new Padding(0, 5, 0, 0);

                        MemoryStream ms = new MemoryStream(array);
                        System.Drawing.Bitmap bitmap = new System.Drawing.Bitmap(ms);
                        product.BackgroundImage = bitmap;

                        product.Controls.Add(productPrice);
                        product.Controls.Add(productName);
                        fpanelMainPlushy.Controls.Add(product);

                        product.Click += new EventHandler(OnClick);

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
            finally
            {
                if (dataReader != null)
                    dataReader.Close();
                if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                    sqlCon.Close();
            }
        }

        private void OnClick(object sender, EventArgs e)
        {
            string tag = ((PictureBox)sender).Tag.ToString();
            string productName = "";
            double productPrice = 0.0;
            double unitPrice = 0.0;
            int availableQuantity = 0;
            char add = '+';
            char remove = '-';
            try
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }

                sqlCon.Open();
                string query = "SELECT P_NAME, P_PRICE, P_QUANTITY FROM PRODUCTS WHERE PID LIKE @Tag";
                using (SqlCommand cmd = new SqlCommand(query, sqlCon))
                {
                    cmd.Parameters.AddWithValue("@Tag", tag);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            productName = reader["P_NAME"].ToString();
                            availableQuantity = Convert.ToInt32(reader["P_QUANTITY"]);
                            unitPrice = Convert.ToDouble(reader["P_PRICE"]);
                            productPrice = Convert.ToDouble(reader["P_PRICE"]);
                        }
                    }
                }

                bool productFound = false;
                foreach (DataGridViewRow row in receipt.Rows)
                {
                    if (row.Cells["OrderName"].Value.ToString() == productName)
                    {
                        productFound = true;
                        int quantity = Convert.ToInt32(row.Cells["OrderQuantity"].Value);
                        if (quantity < availableQuantity)
                        {
                            row.Cells["OrderQuantity"].Value = quantity + 1;
                            row.Cells["OrderPrice"].Value = (quantity + 1) * unitPrice;
                        }
                        else
                        {
                            MessageBox.Show("Maximum quantity reached for this product.");
                        }
                        break;
                    }
                }

                if (!productFound && availableQuantity > 0)
                {
                    receipt.Rows.Add(receipt.Rows.Count + 1, tag, productName, 1, unitPrice.ToString("#,##0.00"), productPrice.ToString("#,##0.00"), add, remove);
                }
                else if (availableQuantity <= 0)
                {
                    MessageBox.Show("Product is out of stock.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                    sqlCon.Close();
            }
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            SqlTransaction transaction = null;
            try
            {
                sqlCon.Open();

                transaction = sqlCon.BeginTransaction();

                foreach (DataGridViewRow row in receipt.Rows)
                {
                    int productId = Convert.ToInt32(row.Cells["OID"].Value);
                    int quantity = Convert.ToInt32(row.Cells["OrderQuantity"].Value);
                    double productPrice = Convert.ToDouble(row.Cells["UnitPrice"].Value);
                    string productName = row.Cells["OrderName"].Value.ToString();

                    string insertQuery = "INSERT INTO ORDERS (PRODUCT_ID, PRODUCT_NAME, CUSTOMER_ID, ORDERED_QUANTITY, PRODUCT_PRICE, ORDER_TOTAL_PRICE, ORDER_DATE) " +
                        "VALUES (@ProductId, @ProductName, @userId, @Quantity, @ProductPrice, @TotalPrice, GETDATE())";
                    SqlCommand insertCmd = new SqlCommand(insertQuery, sqlCon, transaction);
                    insertCmd.Parameters.AddWithValue("@ProductId", productId);
                    insertCmd.Parameters.AddWithValue("@ProductName", productName);
                    insertCmd.Parameters.AddWithValue("@userId", userId);
                    insertCmd.Parameters.AddWithValue("@Quantity", quantity);
                    insertCmd.Parameters.AddWithValue("@ProductPrice", productPrice);
                    insertCmd.Parameters.AddWithValue("@TotalPrice", productPrice * quantity);
                    insertCmd.ExecuteNonQuery();

                    UpdateProductStock(productId, quantity);
                }

                transaction.Commit();

                MessageBox.Show("Order placed successfully!");
                receipt.Rows.Clear();


            }
            catch (Exception ex)
            {
                if (transaction != null)
                    transaction.Rollback();
                MessageBox.Show("Error placing order: " + ex);
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                    sqlCon.Close();
            }
        }
        private void UpdateProductStock(int productId, int purchasedQuantity)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=pirateChanDB;Integrated Security=True;"))
                {
                    connection.Open();

                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            string selectQuery = "SELECT P_QUANTITY FROM PRODUCTS WHERE PID = @ProductId";
                            SqlCommand selectCmd = new SqlCommand(selectQuery, connection, transaction);
                            selectCmd.Parameters.AddWithValue("@ProductId", productId);

                            int currentStock = Convert.ToInt32(selectCmd.ExecuteScalar());

                            int newStock = currentStock - purchasedQuantity;

                            if (newStock < 0)
                            {
                                MessageBox.Show("Insufficient stock.");
                                return;
                            }

                            string updateQuery = "UPDATE PRODUCTS SET P_QUANTITY = @NewStock WHERE PID = @ProductId";
                            SqlCommand updateCmd = new SqlCommand(updateQuery, connection, transaction);
                            updateCmd.Parameters.AddWithValue("@NewStock", newStock);
                            updateCmd.Parameters.AddWithValue("@ProductId", productId);
                            updateCmd.ExecuteNonQuery();

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            MessageBox.Show("Error updating product stock: " + ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void receipt_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void receipt_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void receipt_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == 6) // Check if the clicked cell is the "Add" button
            {
                DataGridViewRow row = receipt.Rows[e.RowIndex];
                int quantity = Convert.ToInt32(row.Cells["OrderQuantity"].Value);
                string productName = row.Cells["OrderName"].Value.ToString(); // Assuming "OrderName" is the column containing the product name

                // Retrieve the stock quantity from the database for the product
                int stockQuantity = 0;
                using (SqlConnection con = new SqlConnection(connection))
                {
                    con.Open();
                    string query = "SELECT P_QUANTITY FROM PRODUCTS WHERE P_NAME = @ProductName";
                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        command.Parameters.AddWithValue("@ProductName", productName);
                        object result = command.ExecuteScalar();
                        if (result != null)
                        {
                            stockQuantity = Convert.ToInt32(result);
                        }
                    }
                }

                if (quantity < stockQuantity) // Check if the quantity is less than the stock quantity
                {
                    row.Cells["OrderQuantity"].Value = quantity + 1; // Increase quantity
                    row.Cells["OrderPrice"].Value = (quantity + 1) * Convert.ToDouble(row.Cells["UnitPrice"].Value); // Update price
                }
                else
                {
                    MessageBox.Show("Cannot add more than available stock quantity.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else if (e.RowIndex >= 0 && e.ColumnIndex == 7) // Check if the clicked cell is the "Remove" button
            {
                DataGridViewRow row = receipt.Rows[e.RowIndex];
                int quantity = Convert.ToInt32(row.Cells["OrderQuantity"].Value);
                if (quantity > 1)
                {
                    row.Cells["OrderQuantity"].Value = quantity - 1; // Decrease quantity
                    row.Cells["OrderPrice"].Value = (quantity - 1) * Convert.ToDouble(row.Cells["UnitPrice"].Value); // Update price
                }
                else
                {
                    receipt.Rows.Remove(row); // Remove the row if the quantity is 1 or less
                }
            }


        }

        private void btnPlaceOrder_Click_1(object sender, EventArgs e)
        {
            // Assuming you have access to your database connection and the customerId
            int customerId = GetCustomerId(); // Replace this with your method to get the customer ID

            // Example SQL query to retrieve the customer name from the database
            string customerName = "";
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open(); // Open the connection here
                string query = "SELECT C_USERNAME FROM CUSTOMERS WHERE CID = @CustomerId";
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    command.Parameters.AddWithValue("@CustomerId", customerId);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            customerName = reader["C_Username"].ToString();
                        }
                    }
                }

                StringBuilder orderSummary = new StringBuilder();
                double totalAmount = 0;

                orderSummary.AppendLine($"Customer: {customerName}");

                // Update stock quantity for each product and construct order summary
                foreach (DataGridViewRow row in receipt.Rows)
                {
                    string productName = row.Cells["OrderName"].Value.ToString();
                    int quantity = Convert.ToInt32(row.Cells["OrderQuantity"].Value);
                    double price = Convert.ToDouble(row.Cells["UnitPrice"].Value);
                    double rowTotal = quantity * price;
                    totalAmount += rowTotal;

                    // Retrieve product information from the database
                    int productId = 0;
                    string productCategory = "";
                    using (SqlCommand productCommand = new SqlCommand("SELECT PID, P_CATEGORY FROM PRODUCTS WHERE P_NAME = @ProductName", con))
                    {
                        productCommand.Parameters.AddWithValue("@ProductName", productName);
                        using (SqlDataReader productReader = productCommand.ExecuteReader())
                        {
                            if (productReader.Read())
                            {
                                productId = Convert.ToInt32(productReader["PID"]);
                                productCategory = productReader["P_CATEGORY"].ToString();
                            }
                        }
                    }

                    // Update stock quantity in the database
                    using (SqlCommand updateCommand = new SqlCommand("UPDATE PRODUCTS SET P_QUANTITY = P_QUANTITY - @Quantity WHERE P_NAME = @ProductName", con))
                    {
                        updateCommand.Parameters.AddWithValue("@Quantity", quantity);
                        updateCommand.Parameters.AddWithValue("@ProductName", productName);
                        updateCommand.ExecuteNonQuery();
                    }

                    // Insert order details into the ORDERS table
                    using (SqlCommand insertCommand = new SqlCommand("INSERT INTO ORDERS (PRODUCT_ID, PRODUCT_NAME, PRODUCT_CATEGORY, CUSTOMER_ID, ORDERED_QUANTITY, PRODUCT_PRICE, ORDER_TOTAL_PRICE, ORDER_DATE) VALUES (@ProductId, @ProductName, @ProductCategory, @CustomerId, @OrderedQuantity, @ProductPrice, @OrderTotalPrice, GETDATE())", con))
                    {
                        insertCommand.Parameters.AddWithValue("@ProductId", productId);
                        insertCommand.Parameters.AddWithValue("@ProductName", productName);
                        insertCommand.Parameters.AddWithValue("@ProductCategory", productCategory);
                        insertCommand.Parameters.AddWithValue("@CustomerId", customerId);
                        insertCommand.Parameters.AddWithValue("@OrderedQuantity", quantity);
                        insertCommand.Parameters.AddWithValue("@ProductPrice", price);
                        insertCommand.Parameters.AddWithValue("@OrderTotalPrice", rowTotal);
                        insertCommand.ExecuteNonQuery();
                    }

                    orderSummary.AppendLine($"{quantity} x {productName} - ${rowTotal:F2}");
                }

                orderSummary.AppendLine($"Total: ${totalAmount:F2}");

                MessageBox.Show(orderSummary.ToString(), "Order Summary", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Clear the form
                receipt.Rows.Clear();
            }

        }

        private int GetCustomerId()
        {
            return userId;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            receipt.Rows.Clear();
        }
    }
}
