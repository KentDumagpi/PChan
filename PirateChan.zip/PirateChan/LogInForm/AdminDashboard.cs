﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace LogInForm
{
    public partial class AdminDashboard : Form
    {
        static bool sidebarExpand;
        SqlConnection con;

        private int userId;
        public AdminDashboard(int userId)
        {
            InitializeComponent();
            con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=pirateChanDB;Integrated Security=True;");
            this.userId = userId;
        }

        private void AdminDashboard_Load(object sender, EventArgs e)
        {
            panelView.Visible = false;
            panelView.Enabled = false; 
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelAddProd.Enabled = false;
            panelAddProd.Visible = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelProd.Visible = false;
            panelProd.Enabled = false; 
            panelOrders.Enabled = false;
            panelEditUser.Visible = false;
            panelEditUser.Enabled = false;
            logoPic.BringToFront();
            lblAdmin.BringToFront();
            sidebar.BringToFront();
        }

        private void sidebarTimer_Tick(object sender, EventArgs e)
        {
            if (sidebarExpand) 
            {
                sidebar.Width -= 10;
                if(sidebar.Width == sidebar.MinimumSize.Width) 
                {
                    sidebarExpand = false;
                    sidebarTimer.Stop();
                }
            }
            else
            {
                sidebar.Width += 10;
                if (sidebar.Width == sidebar.MaximumSize.Width)
                {
                    sidebarExpand = true;
                    sidebarTimer.Stop();
                }
            }
        }

        private void menuBtn_Click(object sender, EventArgs e)
        {
            sidebarTimer.Start();
        }
                
        private void loadDataGridUsers()
        {
            con.Open();
            SqlCommand com = new SqlCommand("SELECT C_ID AS CustomerID," +
                                "C_Username AS Username," +
                                "C_Firstname AS Firstname," +
                                "C_Lastname AS Lastname," +
                                "C_Age AS Age," +
                                "C_Email AS Email," +
                                "C_Address AS Address," +
                                "C_UserType AS Type " + 
                                "FROM CUSTOMERS", con);

            com.ExecuteNonQuery();

            SqlDataAdapter adapter = new SqlDataAdapter(com);
            DataTable data = new DataTable();
            adapter.Fill(data);
            dgvView.DataSource = data;
            con.Close();
        }

        private void loadDataGridProducts()
        {
            try
            {
                con.Open();
                SqlCommand com = new SqlCommand("SELECT P_ID AS ProductID, " +
                                       "P_IMAGE AS ProductImage, " +
                                       "P_NAME AS ProductName, " +
                                       "P_QUANTITY AS ProductQuantity, " +
                                       "P_PRICE AS ProductPrice " +
                                 "FROM PRODUCTS", con);
                SqlDataAdapter dataAdapter = new SqlDataAdapter(com);
                DataTable data = new DataTable();
                data.Clear();
                dataAdapter.Fill(data);
                dgvProducts.DataSource = data;
                DataGridViewImageColumn pImage = new DataGridViewImageColumn();
                pImage = (DataGridViewImageColumn)dgvProducts.Columns[1];
                pImage.ImageLayout = DataGridViewImageCellLayout.Zoom;
                /*
                 SqlCommand com = new SqlCommand("SELECT P_ID AS ProductID, " +
                                       "P_IMAGE, " +
                                       "P_NAME AS ProductName, " +
                                       "P_QUANTITY AS ProductQuantity, " +
                                       "P_PRICE AS ProductPrice " +
                                 "FROM PRODUCTS", con);

                SqlDataReader reader = com.ExecuteReader();

                DataTable data = new DataTable();
                data.Load(reader);
                data.Columns.Add("PIMAGE", typeof(byte[]));
                foreach (DataRow row in data.Rows)
                {
                    string imagePath = row["PIMAGE"].ToString();
                    if (!string.IsNullOrEmpty(imagePath) && File.Exists(imagePath))
                    {
                        row["PIMAGE"] = File.ReadAllBytes(imagePath);
                    }
                }

                dgvProducts.DataSource = data;
                 */
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }



        private void loadDataGridOrders()
        {
            con.Open();
            SqlCommand com = new SqlCommand("SELECT O_ID AS OrderId," +
                    "PRODUCT_ID AS ProductID," +
                    "PRODUCT_NAME AS ProductName," +
                    "ORDERED_QUANTITY AS OrderedQuantity," +
                    "PRODUCT_PRICE AS ProductPrice," +
                    "ORDER_TOTAL_PRICE AS OrderTotalPrice," +
                    "ORDER_DATE AS OrderDate " +
                    "FROM ORDERS", con);


            com.ExecuteNonQuery();

            SqlDataAdapter adapter = new SqlDataAdapter(com);
            DataTable data = new DataTable();
            adapter.Fill(data);
            dgvOrders.DataSource = data;
            con.Close();
        }



        private void LoadAdminAccounts()
        {
            con.Open();
            SqlCommand com = new SqlCommand("SELECT A_ID AS AdminID," +
                                            "A_Username AS Username," +
                                            "A_Password AS Password," +
                                            "A_Firstname AS Firstname," +
                                            "A_Lastname AS Lastname," +
                                            "A_Age AS Age," +
                                            "A_Email AS Email," +
                                            "A_Address AS Address," +
                                            "A_UserType AS Type " +
                                            "FROM ADMINISTRATOR", con);

            com.ExecuteNonQuery();

            SqlDataAdapter adapter = new SqlDataAdapter(com);
            DataTable data = new DataTable();
            adapter.Fill(data);
            dgvEditUser.DataSource = data;
            con.Close();
        }

        private void loadCustomerAccounts()
        {
            con.Open();
            SqlCommand com = new SqlCommand("SELECT C_ID AS CustomerID," +
                                "C_Username AS Username," +
                                "C_Password AS Password," +
                                "C_Firstname AS Firstname," +
                                "C_Lastname AS Lastname," +
                                "C_Age AS Age," +
                                "C_Email AS Email," +
                                "C_Address AS Address," +
                                "C_UserType AS Type " +
                                "FROM CUSTOMERS", con);

            com.ExecuteNonQuery();

            SqlDataAdapter adapter = new SqlDataAdapter(com);
            DataTable data = new DataTable();
            adapter.Fill(data);
            dgvEditUser.DataSource = data;
            con.Close();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            loginPage login = new loginPage();
            login.ShowDialog();
            this.Hide();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelAddProd.Visible = false;
            panelAddProd.Enabled = false;
            panelView.Enabled = false;
            panelView.Visible = false;
            panelProd.Visible = false;
            panelProd.Enabled = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            lblAdmin.Visible = true;
            logoPic.Visible = true;
            panelEditUser.Visible = false;
            panelEditUser.Enabled = false;
            sidebar.BringToFront();
            searchUsers.BringToFront();
            clearSBarUsers.BringToFront();
            sidebarTimer.Start();
            if (sidebarExpand)
            {
                if (sidebar.Width == sidebar.MinimumSize.Width)
                {
                    sidebarExpand = false;
                    sidebarTimer.Stop();
                }
            }
            
        }

        private void btnAccount_Click(object sender, EventArgs e)
        {

        }

        private void btnProducts_Click(object sender, EventArgs e)
        {
            lblAdmin.Visible = false;
            logoPic.Visible = false;
            panelView.Visible = false;
            panelView.Enabled = false;
            panelOrders.Visible = false;
            panelOrders.Enabled = false;
            panelProd.Enabled = true;
            panelProd.Visible = true;
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelAddProd.Visible = false;
            panelAddProd.Enabled = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelEditUser.Visible = false;
            panelEditUser.Enabled = false;
            panelProd.BringToFront();
            sidebar.BringToFront();
            sidebarTimer.Start();
            if (sidebarExpand)
            {
                if (sidebar.Width == sidebar.MinimumSize.Width)
                {
                    sidebarExpand = false;
                    sidebarTimer.Stop();
                }
            }
            loadDataGridProducts();
        }

        private void btnOrders_Click(object sender, EventArgs e)
        {
            lblAdmin.Visible = false;
            logoPic.Visible = false;
            panelView.Visible = false;
            panelView.Enabled = false;
            panelProd.Enabled = false;
            panelProd.Visible = false;
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelAddProd.Visible = false;
            panelAddProd.Enabled = false;
            panelOrders.Enabled = true;
            panelOrders.Visible = true;
            panelEditUser.Visible = false;
            panelEditUser.Enabled = false;
            panelOrders.BringToFront();
            sidebar.BringToFront();
            sidebarTimer.Start();
            if (sidebarExpand)
            {
                if (sidebar.Width == sidebar.MinimumSize.Width)
                {
                    sidebarExpand = false;
                    sidebarTimer.Stop();
                }
            }
            loadDataGridOrders();
        }

        private void btnUsers_Click(object sender, EventArgs e)
        {
            lblAdmin.Visible = false;
            logoPic.Visible = false;
            panelView.Visible = true;
            panelView.Enabled = true;
            panelOrders.Visible = false;
            panelOrders.Enabled = false;
            panelProd.Enabled = false;
            panelProd.Visible = false;
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelAddProd.Visible = false;
            panelAddProd.Enabled = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelEditUser.Visible = false;
            panelEditUser.Enabled = false;
            panelView.BringToFront();
            sidebar.BringToFront();
            sidebarTimer.Start();
            if (sidebarExpand)
            {
                if (sidebar.Width == sidebar.MinimumSize.Width)
                {
                    sidebarExpand = false;
                    sidebarTimer.Stop();
                }
            }
            loadDataGridUsers();
            
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void closeAdd_Click(object sender, EventArgs e)
        {
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelView.Enabled = true;
            panelView.Visible = true;
            lblAdmin.Visible = true;
            logoPic.Visible = true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (rbtnAdmin.Checked || rbtnCustomer.Checked)
            {
                string userType = rbtnAdmin.Checked ? "admin" : "customer";

                string firstname = txtBoxFName.Text;
                string lastname = txtBoxLname.Text;
                string age = txtBoxAge.Text;
                string email = txtBoxEmail.Text;
                string address = txtBoxAddress.Text;
                string username = txtBoxUName.Text;
                string password = txtBoxPassword.Text;
                string encryptedPassword = password;


                if (string.IsNullOrWhiteSpace(firstname))
                {
                    MessageBox.Show("Please enter a valid first name.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; 
                }

                if (string.IsNullOrWhiteSpace(lastname))
                {
                    MessageBox.Show("Please enter a valid last name.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; 
                }

                if (!int.TryParse(age, out int ageValue) || ageValue <= 0)
                {
                    MessageBox.Show("Please enter a valid age.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; 
                }

                if (!IsValidEmail(email))
                {
                    MessageBox.Show("Please enter a valid email address.", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; 
                }

                
                if (string.IsNullOrWhiteSpace(address))
                {
                    MessageBox.Show("Please enter a valid address.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; 
                }

                
                if (string.IsNullOrWhiteSpace(username))
                {
                    MessageBox.Show("Please enter a valid username.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; 
                }

                
                if (string.IsNullOrWhiteSpace(password))
                {
                    MessageBox.Show("Please enter a valid password.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; 
                }

                string insertQuery = "";
                if (userType == "admin")
                {
                    insertQuery = @"INSERT INTO ADMINISTRATOR (A_FIRSTNAME, A_LASTNAME, A_AGE, A_EMAIL, A_ADDRESS, A_USERTYPE, A_USERNAME, A_PASSWORD)
                    VALUES (@Firstname, @Lastname, @Age, @Email, @Address, @UserType, @Username, @Password)";
                }
                else
                {
                    string encryptedPwd = EncryptPassword(password);
                    insertQuery = @"INSERT INTO CUSTOMERS (C_FIRSTNAME, C_LASTNAME, C_AGE, C_EMAIL, C_ADDRESS, C_USERTYPE, C_USERNAME, C_PASSWORD)
                    VALUES (@Firstname, @Lastname, @Age, @Email, @Address, @UserType, @Username, @Password)";
                }

                using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                {
                    cmd.Parameters.AddWithValue("@Firstname", firstname);
                    cmd.Parameters.AddWithValue("@Lastname", lastname);
                    cmd.Parameters.AddWithValue("@Age", ageValue); 
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@Address", address);
                    cmd.Parameters.AddWithValue("@UserType", userType);
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", encryptedPassword); 

                    try
                    {
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show(userType + " added successfully.");
                            ClearInputFields();
                        }
                        else
                        {
                            MessageBox.Show("Failed to add " + userType + ".");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        con.Close();
                    }
                }
                loadDataGridUsers();
            }
            else
            {
                MessageBox.Show("Please select user account type.", "User Type Not Selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void ClearInputFields()
        {
            txtBoxFName.Clear();
            txtBoxLname.Clear();
            txtBoxAge.Clear();
            txtBoxEmail.Clear();
            txtBoxAddress.Clear();
            rbtnAdmin.Checked = false;
            rbtnCustomer.Checked = false;
            txtBoxUName.Clear();
            txtBoxPassword.Clear();
        }

        private bool IsValidEmail(string email)
        {
            string pattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            return Regex.IsMatch(email, pattern);
        }

        private string EncryptPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private string DecryptPassword(string encryptedPassword)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(encryptedPassword));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            uploadPhoto.Filter = "Select image(*.JpG; *.png; *.Gif) | *.JpG; *.png; *.Gif";
            if(uploadPhoto.ShowDialog() == DialogResult.OK)
            {
                prodImage.Image = Image.FromFile(uploadPhoto.FileName);
                txtBoxImgPath.Text = uploadPhoto.FileName;
            }
        }

        private void closeProd_Click(object sender, EventArgs e)
        {
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelAddProd.Enabled = false;
            panelAddProd.Visible = false;
            panelEditUser.Visible = false;
            panelEditUser.Enabled = false;
        }

        private void btnAddProd_Click(object sender, EventArgs e)
        {
            MemoryStream memstr = new MemoryStream();
            prodImage.Image.Save(memstr, prodImage.Image.RawFormat);
            string PName = txtBoxPName.Text;
            string PDesc = txtBoxPDesc.Text;
            int PQuantity = int.Parse(txtBoxQuantity.Text); 
            double PPrice = double.Parse(txtBoxPrice.Text); 

            string insertQuery = @"INSERT INTO PRODUCTS (P_IMAGE, P_NAME, P_QUANTITY, P_PRICE, P_DESCRIPTION)
                           VALUES (@Image, @Name, @Quantity, @Price, @Description)";

            using (SqlCommand cmd = new SqlCommand(insertQuery, con))
            {
                cmd.Parameters.AddWithValue("@Image", memstr.ToArray());
                cmd.Parameters.AddWithValue("@Name", PName);
                cmd.Parameters.AddWithValue("@Quantity", PQuantity);
                cmd.Parameters.AddWithValue("@Price", PPrice);
                cmd.Parameters.AddWithValue("@Description", PDesc);

                try
                {
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Product added successfully.");
                        prodImage.Image = null;
                        txtBoxImgPath.Clear();
                        txtBoxImgPath.Clear();
                        txtBoxPName.Clear();
                        txtBoxPDesc.Clear();
                        txtBoxQuantity.Clear();
                        txtBoxPrice.Clear();
                    }
                    else
                    {
                        MessageBox.Show("Failed to add product.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            loadDataGridProducts();
        }

        private void btnAddOrders_Click(object sender, EventArgs e)
        {

        }

        private void btnEditOrders_Click(object sender, EventArgs e)
        {

        }

        private void btnDeleteOrders_Click(object sender, EventArgs e)
        {

        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelView.Enabled = false;
            panelView.Visible = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelAddProd.Visible = true;
            panelAddProd.Enabled = true;
            panelEditUser.Visible = false;
            panelEditUser.Enabled = false;
            panelAddProd.BringToFront();

        }

        private void btnEditProduct_Click(object sender, EventArgs e)
        {

        }

        private void btnDeleteProduct_Click(object sender, EventArgs e)
        {

        }

        private void btnAddUsers_Click(object sender, EventArgs e)
        {
            panelAddProd.Visible = false;
            panelAddProd.Enabled = false;
            panelView.Enabled = false;
            panelView.Visible = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelAddUsers.Visible = true;
            panelAddUsers.Enabled = true;
            panelEditUser.Visible = false;
            panelEditUser.Enabled = false;
            panelAddUsers.BringToFront();
        }

        private void btnEditUsers_Click(object sender, EventArgs e)
        {
            panelAddProd.Visible = false;
            panelAddProd.Enabled = false;
            panelView.Enabled = false;
            panelView.Visible = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelEditUser.Visible = true;
            panelEditUser.Enabled = true;
            panelEditUser.BringToFront();
        }

        

        private void btnDeleteUsers_Click(object sender, EventArgs e)
        {

        }

        private void EditAdminAccount(DataGridViewRow selectedRow)
        {
            // Populate textboxes with data from the selected row
            txtBoxEditFirstname.Text = selectedRow.Cells["Firstname"].Value.ToString();
            txtBoxEditLastname.Text = selectedRow.Cells["Lastname"].Value.ToString();
            txtBoxEditAge.Text = selectedRow.Cells["Age"].Value.ToString();
            txtBoxEditEmail.Text = selectedRow.Cells["Email"].Value.ToString();
            txtBoxEditAddress.Text = selectedRow.Cells["Address"].Value.ToString();
            txtBoxEditUsername.Text = selectedRow.Cells["Username"].Value.ToString();

            lblAdmin.Visible = false;
            logoPic.Visible = false;
            panelView.Visible = false;
            panelView.Enabled = false;
            panelProd.Visible = false;
            panelProd.Enabled = false;
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelAddProd.Visible = false;
            panelAddProd.Enabled = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelView.BringToFront();
            sidebar.BringToFront();
        }

        private void EditCustomerAccount(DataGridViewRow selectedRow)
        {
            txtBoxEditFirstname.Text = selectedRow.Cells["Firstname"].Value.ToString();
            txtBoxEditLastname.Text = selectedRow.Cells["Lastname"].Value.ToString();
            txtBoxEditAge.Text = selectedRow.Cells["Age"].Value.ToString();
            txtBoxEditEmail.Text = selectedRow.Cells["Email"].Value.ToString();
            txtBoxEditAddress.Text = selectedRow.Cells["Address"].Value.ToString();
            txtBoxEditUsername.Text = selectedRow.Cells["Username"].Value.ToString();


            lblAdmin.Visible = false;
            logoPic.Visible = false;
            panelView.Visible = false;
            panelView.Enabled = false;
            panelProd.Visible = false;
            panelProd.Enabled = false;
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelAddProd.Visible = false;
            panelAddProd.Enabled = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelView.BringToFront();
            sidebar.BringToFront();
        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            ClearInputFields();
            LoadAdminAccounts();
        }

        private void btnCustomer_Click(object sender, EventArgs e)
        {
            ClearInputFields();
            loadCustomerAccounts();
        }

        private void btnEditUser_Click(object sender, EventArgs e)
        { 
            if (dgvEditUser.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dgvEditUser.SelectedRows[0];
                string userType = selectedRow.Cells["Type"].Value.ToString();

                if (userType == "admin")
                {
                    EditAdminAccount(selectedRow);
                }
                else if (userType == "customer")
                {
                    EditCustomerAccount(selectedRow);
                }
                else
                {
                    MessageBox.Show("Unknown user type.");
                    return;
                }

                string firstname = txtBoxEditFirstname.Text;
                string lastname = txtBoxEditLastname.Text;
                int age;
                bool isAgeValid = int.TryParse(txtBoxEditAge.Text, out age);

                string email = txtBoxEditEmail.Text;
                string address = txtBoxEditAddress.Text;
                string username = txtBoxEditUsername.Text;

                using (SqlCommand cmd = new SqlCommand("", con))
                {
                    try
                    {
                        con.Open();
                        if (userType == "admin")
                        {
                            cmd.CommandText = @"UPDATE ADMINISTRATOR 
                                            SET A_FIRSTNAME = COALESCE(@Firstname, A_FIRSTNAME), 
                                                A_LASTNAME = COALESCE(@Lastname, A_LASTNAME), 
                                                A_AGE = COALESCE(@Age, A_AGE), 
                                                A_EMAIL = COALESCE(@Email, A_EMAIL), 
                                                A_ADDRESS = COALESCE(@Address, A_ADDRESS), 
                                                A_USERNAME = COALESCE(@Username, A_USERNAME)
                                            WHERE A_ID = @AdminID";
                            cmd.Parameters.AddWithValue("@AdminID", selectedRow.Cells["AdminID"].Value);
                        }
                        else if (userType == "customer")
                        {
                            cmd.CommandText = @"UPDATE CUSTOMERS 
                                            SET C_FIRSTNAME = COALESCE(@FIRSTNAME, C_FIRSTNAME), 
                                                C_LASTNAME = COALESCE(@Lastname, C_LASTNAME), 
                                                C_AGE = COALESCE(@Age, C_AGE), 
                                                C_EMAIL = COALESCE(@Email, C_EMAIL), 
                                                C_ADDRESS = COALESCE(@Address, C_ADDRESS), 
                                                C_USERNAME = COALESCE(@Username, C_USER)
                                            WHERE C_ID = @CustomerID";

                            cmd.Parameters.AddWithValue("@CustomerID", selectedRow.Cells["CustomerID"].Value);
                        }

                        cmd.Parameters.AddWithValue("@Firstname", (object)firstname ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@Lastname", (object)lastname ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@Age", isAgeValid ? (object)age : DBNull.Value);
                        cmd.Parameters.AddWithValue("@Email", (object)email ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@Address", (object)address ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@Username", (object)username ?? DBNull.Value);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("User data updated successfully.");
                            txtBoxEditFirstname.Clear();
                            txtBoxEditLastname.Clear();
                            txtBoxEditAge.Clear();
                            txtBoxEditEmail.Clear();
                            txtBoxEditAddress.Clear();
                            txtBoxEditUsername.Clear();

                            if (userType == "admin")
                            {
                                LoadAdminAccounts();
                            }
                            else if (userType == "customer")
                            {
                                loadCustomerAccounts();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Failed to update user data.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex);
                    }
                    finally
                    {
                        con.Close(); 
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a user to edit.");
            }
        }





        private void closeEditUser_Click(object sender, EventArgs e)
        {
            panelEditUser.Visible = false;
            panelEditUser.Enabled = false;
            panelView.Enabled = true;
            panelView.Visible = true;
        }

        private void dgvEditUser_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dgvEditUser.Rows[e.RowIndex];
                string userType = selectedRow.Cells["Type"].Value.ToString();

                if (userType == "admin")
                {
                    EditAdminAccount(selectedRow);
                }
                else if (userType == "customer")
                {
                    EditCustomerAccount(selectedRow);
                }
            }
        }

        private void dgvEditUser_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void panelEditUser_Paint(object sender, PaintEventArgs e)
        {

        }

        private void sidebar_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void searchUsers_Click(object sender, EventArgs e)
        {

        }

        private void txtBoxSearchUsers_TextChanged(object sender, EventArgs e)
        {

        }

        private void clearSBarUsers_Click(object sender, EventArgs e)
        {

        }

        private void panelView_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label35_Click(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void lblLabel_Click(object sender, EventArgs e)
        {

        }

        private void dgvView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void panelOrders_Paint(object sender, PaintEventArgs e)
        {

        }

        private void orderlbl_Click(object sender, EventArgs e)
        {

        }

        private void dgvOrders_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label27_Click(object sender, EventArgs e)
        {

        }

        private void label28_Click(object sender, EventArgs e)
        {

        }

        private void searchOrders_Click(object sender, EventArgs e)
        {

        }

        private void clearSBarOrders_Click(object sender, EventArgs e)
        {

        }

        private void txtBoxSearchOrders_TextChanged(object sender, EventArgs e)
        {

        }

        private void rbtnCustomer_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbtnAdmin_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void txtBoxPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBoxUName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBoxAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBoxEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBoxAge_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBoxLname_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBoxFName_TextChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panelAddProd_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtBoxImgPath_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBoxPrice_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBoxQuantity_TextChanged(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void txtBoxPDesc_TextChanged(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void prodImage_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void txtBoxPName_TextChanged(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void label23_Click(object sender, EventArgs e)
        {

        }

        private void label33_Click(object sender, EventArgs e)
        {

        }

        private void txtBoxEditUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void label32_Click(object sender, EventArgs e)
        {

        }

        private void txtBoxEditAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void label31_Click(object sender, EventArgs e)
        {

        }

        private void txtBoxEditEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void label30_Click(object sender, EventArgs e)
        {

        }

        private void txtBoxEditAge_TextChanged(object sender, EventArgs e)
        {

        }

        private void label29_Click(object sender, EventArgs e)
        {

        }

        private void txtBoxEditLastname_TextChanged(object sender, EventArgs e)
        {

        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void txtBoxEditFirstname_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
